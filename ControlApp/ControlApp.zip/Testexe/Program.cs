﻿using System;
using System.Windows;
class Program
{
    static void Main()
    {
        MessageBox.Show("Hello", "System Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
}
