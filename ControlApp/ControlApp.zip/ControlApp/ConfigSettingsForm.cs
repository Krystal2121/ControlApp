﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControlApp
{
    public partial class ConfigSettingsForm : Form
    {
        public ConfigSettingsForm()
        {
            InitializeComponent();
        }
        bool runallchange;
        private void button1_Click(object sender, EventArgs e)
        {
            Configuration myconfig = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            KeyValueConfigurationCollection apps = myconfig.AppSettings.Settings;
            apps.Remove("LocalDrive");
            apps.Remove("AutoRun");
            apps.Remove("UserName");
            apps.Remove("Password");
            apps.Remove("Delay");
            apps.Remove("RunAll");
            apps.Remove("Clickthroughpop");
            apps.Remove("Showblocked");
            if (showblocked.Checked == true)
                apps.Add("Showblocked", "True");
            else
                apps.Add("Showblocked", "False");
            if (clickch.Checked == true)
                apps.Add("Clickthroughpop", "True");
            else
                apps.Add("Clickthroughpop", "False");
            apps.Add("LocalDrive", textBox1.Text);
            if (checkBox1.Checked == true)
                apps.Add("AutoRun", "True");
            else
                apps.Add("AutoRun", "False");
            apps.Add("UserName", textBox2.Text);
            apps.Add("Password", textBox3.Text);
            if (checkBox2.Checked == true)
                apps.Add("RunAll", "True");
            else
                apps.Add("RunAll", "False");
            apps.Add("Delay", textBox5.Text);
            myconfig.Save(ConfigurationSaveMode.Full);
            ConfigurationManager.RefreshSection(myconfig.AppSettings.SectionInformation.Name);
            this.Close();
        }
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            runallchange = false;
            textBox1.Text = ConfigurationManager.AppSettings["LocalDrive"];
            textBox2.Text = ConfigurationManager.AppSettings["UserName"];
            textBox3.Text = ConfigurationManager.AppSettings["Password"];
            if (ConfigurationManager.AppSettings["AutoRun"] == "True")
                checkBox1.Checked = true;
            else
                checkBox1.Checked = false;
            textBox5.Text = ConfigurationManager.AppSettings["Delay"];
            if (ConfigurationManager.AppSettings["RunAll"] == "True")
                checkBox2.Checked = true;
            else
                checkBox2.Checked = false;
            if (ConfigurationManager.AppSettings["Clickthroughpop"] == "True")
                clickch.Checked = true;
            else
                clickch.Checked = false;
            if (ConfigurationManager.AppSettings["Showblocked"] == "True")
                showblocked.Checked = true;
            else
                showblocked.Checked = false;
        }

        private void ConfigSettingsForm_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string Password = ConfigurationManager.AppSettings["Password"];
            if ((Password != null) || (Password == ""))
            {
                Password = textBox3.Text;
            }
            string user = ConfigurationManager.AppSettings["UserName"];
            if ((user != null) || (user == ""))
            {
                user = textBox2.Text;
            }
            System.Diagnostics.Process.Start(new ProcessStartInfo
            {
                FileName = "https://www.thecontrolapp.co.uk/Pages/Sub/SubSettings.aspx?user=" + user + "&password=" + Password,
                UseShellExecute = true
            });
        }
    }
}
