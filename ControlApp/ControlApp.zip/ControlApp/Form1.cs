﻿
using Microsoft.VisualBasic.ApplicationServices;
using System.ComponentModel;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Policy;


namespace ControlApp
{
    public partial class Form1 : Form
    {
        Utils utils;
        public Form1()
        {
            InitializeComponent();
            utils = new Utils();
        }
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            meuser.Text = ConfigurationManager.AppSettings["UserName"].ToString();
        }

        private void configToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ConfigSettingsForm form = new ConfigSettingsForm();
            form.ShowDialog();
            meuser.Text = ConfigurationManager.AppSettings["UserName"].ToString();
        }

        BackgroundWorker bg;
        string[] currentsender;
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (ConfigurationManager.AppSettings["RunAll"] == "True")
            {
                currentsender = utils.GetLatestItem();
                string user = ConfigurationManager.AppSettings["UserName"].ToString();
                string pwd = ConfigurationManager.AppSettings["Password"].ToString();
                string vrs = "0993";
                string[] ret = utils.getoutstanding(user, pwd, vrs);
                Nocomds.Text = ret[0];
                whonxtlbl.Text = ret[1];
            }

        }

        private void button11_Click(object sender, EventArgs e)
        {
            string[] strings = MainTxt.Text.Split("|||");
            string ret = "";
            foreach (string s in strings)
            {
                ret += utils.Decrypt(s) + "|||";
            }
            MainTxt.Text = ret;
        }
        private static Guid FolderDownloads = new Guid("374DE290-123F-4565-9164-39C4925E467B");
        [DllImport("shell32.dll", CharSet = CharSet.Auto)]
        private static extern int SHGetKnownFolderPath(ref Guid id, int flags, IntPtr token, out IntPtr path);

        public static string GetDownloadsPath()
        {
            if (Environment.OSVersion.Version.Major < 6) throw new NotSupportedException();

            IntPtr pathPtr = IntPtr.Zero;

            try
            {
                SHGetKnownFolderPath(ref FolderDownloads, 0, IntPtr.Zero, out pathPtr);
                return Marshal.PtrToStringUni(pathPtr);
            }
            finally
            {
                Marshal.FreeCoTaskMem(pathPtr);
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            string ld = ConfigurationManager.AppSettings["LocalDrive"];
            if ((ld == null) || (ld == ""))
            {
                Configuration myconfig = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                KeyValueConfigurationCollection apps = myconfig.AppSettings.Settings;
                string dl = GetDownloadsPath() + "\\";
                apps.Remove("LocalDrive");
                apps.Add("LocalDrive", dl);
                myconfig.Save(ConfigurationSaveMode.Full);
                ConfigurationManager.RefreshSection(myconfig.AppSettings.SectionInformation.Name);
            }
            else if (ld.Substring(ld.Length - 1, 1) != "\\")
            {
                Configuration myconfig = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                KeyValueConfigurationCollection apps = myconfig.AppSettings.Settings;
                string dl = ld + "\\";
                apps.Remove("LocalDrive");
                apps.Add("LocalDrive", dl);
                myconfig.Save(ConfigurationSaveMode.Full);
                ConfigurationManager.RefreshSection(myconfig.AppSettings.SectionInformation.Name);
            }
            string user = ConfigurationManager.AppSettings["UserName"].ToString();
            string pwd = ConfigurationManager.AppSettings["Password"].ToString();
            string vrs = "0993";
            string[] ret = utils.getoutstanding(user, pwd, vrs);
            Nocomds.Text = ret[0];
            whonxtlbl.Text = ret[1];
            timer1.Enabled = true;
            timer1.Interval = Convert.ToInt16(ConfigurationManager.AppSettings["Delay"]) * 1000;
        }

        private void optionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Options options = new Options();
            options.ShowDialog();
        }
        public void createmessageline(string code)
        {
            string line = "";
            if (webtxt.Text == "")
            {
                if (filetxt.Text == "")
                    MessageBox.Show("Please enter a file name.");
                else
                {
                    long length = new System.IO.FileInfo(filetxt.Text).Length;
                    if (length < 2000000)
                    {
                        utils.sendftpfile(filetxt.Text);
                        line = code + "=FTP" + Path.GetFileName(filetxt.Text);
                    }
                    else
                    {
                        MessageBox.Show("File too big");
                        return;
                    }
                }
            }
            else
            {
                if (webtxt.Text.Contains("booru.allthefallen.moe"))
                {
                    MessageBox.Show("Website banned");
                }
                else
                {
                    line = code + "=" + webtxt.Text;
                }
            }
            line = utils.Ecrypt(line);
            MainTxt.Text += line + "|||";
            webtxt.Text = "";
            filetxt.Text = "";
        }
        private void DownloadFile_Btn_Click(object sender, EventArgs e)
        {
            createmessageline("D");
        }

        private void ChangeWall_Btn_Click(object sender, EventArgs e)
        {
            string file = "";
            if (webtxt.Text != "")
                file = webtxt.Text;
            if (filetxt.Text != "")
                file = filetxt.Text;
            try
            {
                string filetype = Path.GetExtension(file);
                if ((filetype == ".jpg") || (filetype == ".jpeg") || (filetype == ".png"))
                    createmessageline("P");
                else
                    MessageBox.Show("Incorrect file type. Please use only image files.");
            }
            catch
            {
                MessageBox.Show("Incorrect file type. Please use only image files.");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string file = "";
            if (webtxt.Text != "")
                file = webtxt.Text;
            if (filetxt.Text != "")
                file = filetxt.Text;
            try
            {
                string filetype = Path.GetExtension(file);
                if ((filetype == ".exe") || (filetype == ".bat"))
                    createmessageline("R");
                else
                    MessageBox.Show("Incorrect file type. Please use only exe or Bat");
            }
            catch
            {
                MessageBox.Show("Incorrect file type. Please use only exe or Bat");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            createmessageline("W");
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            string file = "";
            if (webtxt.Text != "")
                file = webtxt.Text;
            if (filetxt.Text != "")
                file = filetxt.Text;
            try
            {
                string filetype = Path.GetExtension(file);
                if ((filetype == ".jpg") || (filetype == ".jpeg") || (filetype == ".webm") || (filetype == ".webp") || (filetype == ".png") || (filetype == ".mp4") || (filetype == ".gif") || (filetype == ".avi"))
                    createmessageline("U");
                else
                    MessageBox.Show("Incorrect file type. Please use only image or movie files");
            }
            catch
            {
                MessageBox.Show("Incorrect file type. Please use only image or movie files");
            }
        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            createmessageline("O");
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            if (msgbx.Text.Length < 2000)
            {
                string line = "M=" + msgbx.Text + "&&&" + btnbx.Text;
                line = utils.Ecrypt(line);
                MainTxt.Text += line + "|||";
            }
            else
                MessageBox.Show("Message is too long");
        }

        private void button13_Click_1(object sender, EventArgs e)
        {
            string line = "V=" + msgbx.Text;
            line = utils.Ecrypt(line);
            MainTxt.Text += line + "|||";
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            string[] lines;
            if (MainTxt.Text.IndexOf("|||") > 0)
            {
                lines = MainTxt.Text.Split("|||");
            }
            else
            {
                lines = new string[] { MainTxt.Text };
            }
            string me = ConfigurationManager.AppSettings["UserName"].ToString();
            utils.run_process(lines, me);
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            Clipboard.SetText(MainTxt.Text);
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            MainTxt.Text = "";
        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            try
            {
                string usernm;
                bool all;
                if ((groupcmbx.SelectedIndex == 0) || (groupcmbx.SelectedIndex == -1))
                {
                    usernm = touser.Text;
                    all = All_chk.Checked;
                }
                else
                {
                    usernm = getgroup().ToString();
                    all = true;
                }
                string comm = MainTxt.Text;
                utils.sendcmd(usernm, comm, all);
                groupcmbx.SelectedIndex = 0;
                touser.Text = "";
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
                utils.writetolog(msg, msg);
            }
        }

        private void RunNxt_Click(object sender, EventArgs e)
        {
            currentsender = utils.GetLatestItem();
            string user = ConfigurationManager.AppSettings["UserName"].ToString();
            string pwd = ConfigurationManager.AppSettings["Password"].ToString();
            string vrs = "0993";
            string[] ret = utils.getoutstanding(user, pwd, vrs);
            Nocomds.Text = ret[0];
            whonxtlbl.Text = ret[1];
        }

        private void button10_Click(object sender, EventArgs e)
        {
            //Block sender
            var result = MessageBox.Show("Are you sure", "Sure?", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                utils.SendBlockReport(currentsender[0], "", "0");
            }
        }

        private void RptSend_Click(object sender, EventArgs e)
        {
            //report sender
            var result = MessageBox.Show("Are you sure", "Sure?", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                utils.SendBlockReport(currentsender[0], currentsender[1], "1");
            }
        }

        private void button11_Click_1(object sender, EventArgs e)
        {
            string user = ConfigurationManager.AppSettings["UserName"].ToString();
            string pwd = ConfigurationManager.AppSettings["Password"].ToString();
            string vrs = "0993";
            string[] res = utils.getoutstanding(user, pwd, vrs);
            Nocomds.Text = res[0];
            whonxtlbl.Text = res[1];
        }

        private void button12_Click(object sender, EventArgs e)
        {
            utils.sendftpfile(filetxt.Text);
        }
        private void button14_Click(object sender, EventArgs e)
        {
            string[] strings = MainTxt.Text.Split("|||");
            MainTxt.Text = "";
            foreach (string s in strings)
            {
                MainTxt.Text += utils.Decrypt(s);
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            DialogResult dr = openFileDialog1.ShowDialog();
            filetxt.Text = openFileDialog1.FileName;
        }

        private void button16_Click(object sender, EventArgs e)
        {
            utils.getftpfile(filetxt.Text);
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        public int getgroup()
        {
            int sel = groupcmbx.SelectedIndex;
            return (sel + 1) * -1;
        }
        private void button17_Click(object sender, EventArgs e)
        {
            string file = "";
            if (webtxt.Text != "")
                file = webtxt.Text;
            if (filetxt.Text != "")
                file = filetxt.Text;
            try
            {
                string filetype = Path.GetExtension(file);
                if ((filetype == ".jpg") || (filetype == ".jpeg") || (filetype == ".webp") || (filetype == ".webm") || (filetype == ".png") || (filetype == ".mp4") || (filetype == ".gif") || (filetype == ".avi"))
                    createmessageline("S");
                else
                    MessageBox.Show("Incorrect file type. Please use only image or movie files");
            }
            catch
            {
                MessageBox.Show("Incorrect file type. Please use only image or movie files");
            }
        }

        private void button12_Click_2(object sender, EventArgs e)
        {
            string usernm;
            bool all = false;
            string comm = MainTxt.Text;
            if (groupcmbx.SelectedIndex == 0)
            {
                if (currentsender[0] != "-1")
                    utils.sendcmd(currentsender[0], comm, all);
            }
            else
            {
                if ((currentsender[0] != null) && (Convert.ToInt16(currentsender[0]) >= -1))
                {
                    usernm = getgroup().ToString();
                    all = true;
                    utils.sendcmd(usernm, comm, all);
                }
            }

        }

        private void wfmbtn_Click(object sender, EventArgs e)
        {
            if (int.TryParse(wfmnotxt.Text, out int x))
            {
                string line = "F=" + wfmtxt.Text + "&&&" + wfmnotxt.Text;
                line = utils.Ecrypt(line);
                MainTxt.Text += line + "|||";
            }
            else
                MessageBox.Show("How many must be a number.");
        }

        private void plaudbtn_Click(object sender, EventArgs e)
        {
            string file = "";
            if (webtxt.Text != "")
                file = webtxt.Text;
            if (filetxt.Text != "")
                file = filetxt.Text;
            try
            {
                string filetype = Path.GetExtension(file);
                if ((filetype == ".mp3") || (filetype == ".wav"))
                    createmessageline("A");
                else
                    MessageBox.Show("Incorrect file type. Please use only sound files");
            }
            catch
            {
                MessageBox.Show("Incorrect file type. Please use only sound files");
            }

        }

        private void button16_Click_1(object sender, EventArgs e)
        {
            MainTxt.Text = utils.Ecrypt(MainTxt.Text);
        }

        private void tkscreen_Click(object sender, EventArgs e)
        {
            string line = "1=Yes";
            line = utils.Ecrypt(line);
            MainTxt.Text += line + "|||";
        }

        private void button18_Click(object sender, EventArgs e)
        {

        }

        private void ClearOut_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure?", "Sure?", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                string user = ConfigurationManager.AppSettings["UserName"].ToString();
                string pwd = ConfigurationManager.AppSettings["Password"].ToString();
                string vrs = "0993";
                utils.deleteoutstanding(user, pwd, vrs);
                string[] res = utils.getoutstanding(user, pwd, vrs);
                Nocomds.Text = res[0];
                whonxtlbl.Text = res[1];
            }
        }

        private void wtchfrmebtn_Click(object sender, EventArgs e)
        {
            createmessageline("2");
        }

        private void twitter_Click(object sender, EventArgs e)
        {
            if (msgbx.Text.Length < 2000)
            {
                string line = "3=" + msgbx.Text;
                line = utils.Ecrypt(line);
                MainTxt.Text += line + "|||";
            }
            else
                MessageBox.Show("Message is too long");
        }

        private void button19_Click(object sender, EventArgs e)
        {
            string line = "4=Yes";
            line = utils.Ecrypt(line);
            MainTxt.Text += line + "|||";
        }
    }
}
