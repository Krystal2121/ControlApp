﻿namespace ControlApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            menuStrip1 = new MenuStrip();
            settingToolStripMenuItem = new ToolStripMenuItem();
            configToolStripMenuItem = new ToolStripMenuItem();
            optionsToolStripMenuItem = new ToolStripMenuItem();
            meuser = new TextBox();
            label3 = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            ClearOut = new Button();
            label12 = new Label();
            whonxtlbl = new Label();
            button11 = new Button();
            RptSend = new Button();
            button10 = new Button();
            RunNxt = new Button();
            label8 = new Label();
            Nocomds = new TextBox();
            tabPage2 = new TabPage();
            twitter = new Button();
            wtchfrmebtn = new Button();
            tkscreen = new Button();
            label11 = new Label();
            groupcmbx = new ComboBox();
            plaudbtn = new Button();
            wfmbtn = new Button();
            wfmtxt = new TextBox();
            label10 = new Label();
            label7 = new Label();
            wfmnotxt = new TextBox();
            button12 = new Button();
            button17 = new Button();
            button15 = new Button();
            label9 = new Label();
            filetxt = new TextBox();
            button13 = new Button();
            label6 = new Label();
            label5 = new Label();
            btnbx = new TextBox();
            msgbx = new TextBox();
            All_chk = new CheckBox();
            label4 = new Label();
            button9 = new Button();
            touser = new TextBox();
            button8 = new Button();
            button7 = new Button();
            button6 = new Button();
            button5 = new Button();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            label2 = new Label();
            button1 = new Button();
            MainTxt = new TextBox();
            label1 = new Label();
            ChangeWall_Btn = new Button();
            webtxt = new TextBox();
            DownloadFile_Btn = new Button();
            button14 = new Button();
            openFileDialog1 = new OpenFileDialog();
            button16 = new Button();
            button18 = new Button();
            button19 = new Button();
            menuStrip1.SuspendLayout();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            tabPage2.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { settingToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(868, 24);
            menuStrip1.TabIndex = 8;
            menuStrip1.Text = "menuStrip1";
            // 
            // settingToolStripMenuItem
            // 
            settingToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { configToolStripMenuItem, optionsToolStripMenuItem });
            settingToolStripMenuItem.Name = "settingToolStripMenuItem";
            settingToolStripMenuItem.Size = new Size(56, 20);
            settingToolStripMenuItem.Text = "Setting";
            // 
            // configToolStripMenuItem
            // 
            configToolStripMenuItem.Name = "configToolStripMenuItem";
            configToolStripMenuItem.Size = new Size(116, 22);
            configToolStripMenuItem.Text = "Config";
            configToolStripMenuItem.Click += configToolStripMenuItem_Click;
            // 
            // optionsToolStripMenuItem
            // 
            optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            optionsToolStripMenuItem.Size = new Size(116, 22);
            optionsToolStripMenuItem.Text = "Options";
            optionsToolStripMenuItem.Click += optionsToolStripMenuItem_Click;
            // 
            // meuser
            // 
            meuser.Enabled = false;
            meuser.Location = new Point(102, 37);
            meuser.Name = "meuser";
            meuser.Size = new Size(143, 23);
            meuser.TabIndex = 15;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(31, 40);
            label3.Name = "label3";
            label3.Size = new Size(65, 15);
            label3.TabIndex = 16;
            label3.Text = "User Name";
            // 
            // timer1
            // 
            timer1.Interval = 1500;
            timer1.Tick += timer1_Tick;
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Location = new Point(31, 66);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(825, 422);
            tabControl1.TabIndex = 32;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(ClearOut);
            tabPage1.Controls.Add(label12);
            tabPage1.Controls.Add(whonxtlbl);
            tabPage1.Controls.Add(button11);
            tabPage1.Controls.Add(RptSend);
            tabPage1.Controls.Add(button10);
            tabPage1.Controls.Add(RunNxt);
            tabPage1.Controls.Add(label8);
            tabPage1.Controls.Add(Nocomds);
            tabPage1.Location = new Point(4, 24);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(817, 394);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Received Commands";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // ClearOut
            // 
            ClearOut.Location = new Point(22, 81);
            ClearOut.Name = "ClearOut";
            ClearOut.Size = new Size(113, 23);
            ClearOut.TabIndex = 11;
            ClearOut.Text = "Clear Outstanding";
            ClearOut.UseVisualStyleBackColor = true;
            ClearOut.Click += ClearOut_Click;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(44, 50);
            label12.Name = "label12";
            label12.Size = new Size(78, 15);
            label12.TabIndex = 10;
            label12.Text = "Next is from :";
            // 
            // whonxtlbl
            // 
            whonxtlbl.AutoSize = true;
            whonxtlbl.Location = new Point(128, 50);
            whonxtlbl.Name = "whonxtlbl";
            whonxtlbl.Size = new Size(44, 15);
            whonxtlbl.TabIndex = 9;
            whonxtlbl.Text = "label12";
            // 
            // button11
            // 
            button11.Location = new Point(236, 17);
            button11.Name = "button11";
            button11.Size = new Size(100, 23);
            button11.TabIndex = 8;
            button11.Text = "Check";
            button11.UseVisualStyleBackColor = true;
            button11.Click += button11_Click_1;
            // 
            // RptSend
            // 
            RptSend.Location = new Point(700, 46);
            RptSend.Name = "RptSend";
            RptSend.Size = new Size(100, 23);
            RptSend.TabIndex = 7;
            RptSend.Text = "Report Sender";
            RptSend.UseVisualStyleBackColor = true;
            RptSend.Click += RptSend_Click;
            // 
            // button10
            // 
            button10.Location = new Point(700, 17);
            button10.Name = "button10";
            button10.Size = new Size(100, 23);
            button10.TabIndex = 6;
            button10.Text = "Block Sender";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // RunNxt
            // 
            RunNxt.Location = new Point(236, 46);
            RunNxt.Name = "RunNxt";
            RunNxt.Size = new Size(100, 23);
            RunNxt.TabIndex = 2;
            RunNxt.Text = "Run Next";
            RunNxt.UseVisualStyleBackColor = true;
            RunNxt.Click += RunNxt_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(128, 20);
            label8.Name = "label8";
            label8.Size = new Size(102, 15);
            label8.TabIndex = 1;
            label8.Text = "No of Commands";
            // 
            // Nocomds
            // 
            Nocomds.Location = new Point(22, 17);
            Nocomds.Name = "Nocomds";
            Nocomds.Size = new Size(100, 23);
            Nocomds.TabIndex = 0;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(button19);
            tabPage2.Controls.Add(twitter);
            tabPage2.Controls.Add(wtchfrmebtn);
            tabPage2.Controls.Add(tkscreen);
            tabPage2.Controls.Add(label11);
            tabPage2.Controls.Add(groupcmbx);
            tabPage2.Controls.Add(plaudbtn);
            tabPage2.Controls.Add(wfmbtn);
            tabPage2.Controls.Add(wfmtxt);
            tabPage2.Controls.Add(label10);
            tabPage2.Controls.Add(label7);
            tabPage2.Controls.Add(wfmnotxt);
            tabPage2.Controls.Add(button12);
            tabPage2.Controls.Add(button17);
            tabPage2.Controls.Add(button15);
            tabPage2.Controls.Add(label9);
            tabPage2.Controls.Add(filetxt);
            tabPage2.Controls.Add(button13);
            tabPage2.Controls.Add(label6);
            tabPage2.Controls.Add(label5);
            tabPage2.Controls.Add(btnbx);
            tabPage2.Controls.Add(msgbx);
            tabPage2.Controls.Add(All_chk);
            tabPage2.Controls.Add(label4);
            tabPage2.Controls.Add(button9);
            tabPage2.Controls.Add(touser);
            tabPage2.Controls.Add(button8);
            tabPage2.Controls.Add(button7);
            tabPage2.Controls.Add(button6);
            tabPage2.Controls.Add(button5);
            tabPage2.Controls.Add(button4);
            tabPage2.Controls.Add(button3);
            tabPage2.Controls.Add(button2);
            tabPage2.Controls.Add(label2);
            tabPage2.Controls.Add(button1);
            tabPage2.Controls.Add(MainTxt);
            tabPage2.Controls.Add(label1);
            tabPage2.Controls.Add(ChangeWall_Btn);
            tabPage2.Controls.Add(webtxt);
            tabPage2.Controls.Add(DownloadFile_Btn);
            tabPage2.Location = new Point(4, 24);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(817, 394);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Send Command";
            tabPage2.UseVisualStyleBackColor = true;
            tabPage2.Click += tabPage2_Click;
            // 
            // twitter
            // 
            twitter.Location = new Point(18, 262);
            twitter.Name = "twitter";
            twitter.Size = new Size(95, 23);
            twitter.TabIndex = 75;
            twitter.Text = "Twitter post";
            twitter.UseVisualStyleBackColor = true;
            twitter.Click += twitter_Click;
            // 
            // wtchfrmebtn
            // 
            wtchfrmebtn.Location = new Point(274, 179);
            wtchfrmebtn.Name = "wtchfrmebtn";
            wtchfrmebtn.Size = new Size(118, 23);
            wtchfrmebtn.TabIndex = 74;
            wtchfrmebtn.Text = "Watch for me";
            wtchfrmebtn.UseVisualStyleBackColor = true;
            wtchfrmebtn.Click += wtchfrmebtn_Click;
            // 
            // tkscreen
            // 
            tkscreen.Location = new Point(410, 31);
            tkscreen.Name = "tkscreen";
            tkscreen.Size = new Size(75, 46);
            tkscreen.TabIndex = 73;
            tkscreen.Text = "Take Screenshot";
            tkscreen.UseVisualStyleBackColor = true;
            tkscreen.Click += tkscreen_Click;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(425, 350);
            label11.Name = "label11";
            label11.Size = new Size(40, 15);
            label11.TabIndex = 72;
            label11.Text = "Group";
            // 
            // groupcmbx
            // 
            groupcmbx.FormattingEnabled = true;
            groupcmbx.Items.AddRange(new object[] { "", "Hypno", "Goon", "Censored", "Girl Cock", "Male focus", "Female focus", "BDSM", "Extreme", "Trans", "Panic", "Blackmail/Exposure", "Latex/Rubber" });
            groupcmbx.Location = new Point(507, 347);
            groupcmbx.Name = "groupcmbx";
            groupcmbx.Size = new Size(140, 23);
            groupcmbx.TabIndex = 71;
            // 
            // plaudbtn
            // 
            plaudbtn.Location = new Point(147, 179);
            plaudbtn.Name = "plaudbtn";
            plaudbtn.Size = new Size(118, 23);
            plaudbtn.TabIndex = 70;
            plaudbtn.Text = "Play Audio";
            plaudbtn.UseVisualStyleBackColor = true;
            plaudbtn.Click += plaudbtn_Click;
            // 
            // wfmbtn
            // 
            wfmbtn.Location = new Point(17, 346);
            wfmbtn.Name = "wfmbtn";
            wfmbtn.Size = new Size(105, 23);
            wfmbtn.TabIndex = 69;
            wfmbtn.Text = "Write for me";
            wfmbtn.UseVisualStyleBackColor = true;
            wfmbtn.Click += wfmbtn_Click;
            // 
            // wfmtxt
            // 
            wfmtxt.Location = new Point(17, 317);
            wfmtxt.Name = "wfmtxt";
            wfmtxt.Size = new Size(284, 23);
            wfmtxt.TabIndex = 68;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(307, 298);
            label10.Name = "label10";
            label10.Size = new Size(70, 15);
            label10.TabIndex = 67;
            label10.Text = "How many?";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(21, 298);
            label7.Name = "label7";
            label7.Size = new Size(96, 15);
            label7.TabIndex = 66;
            label7.Text = "Write for me text";
            // 
            // wfmnotxt
            // 
            wfmnotxt.Location = new Point(307, 317);
            wfmnotxt.Name = "wfmnotxt";
            wfmnotxt.Size = new Size(44, 23);
            wfmnotxt.TabIndex = 65;
            // 
            // button12
            // 
            button12.Location = new Point(697, 349);
            button12.Name = "button12";
            button12.Size = new Size(100, 23);
            button12.TabIndex = 64;
            button12.Text = "Responds";
            button12.UseVisualStyleBackColor = true;
            button12.Click += button12_Click_2;
            // 
            // button17
            // 
            button17.Location = new Point(24, 179);
            button17.Name = "button17";
            button17.Size = new Size(118, 23);
            button17.TabIndex = 63;
            button17.Text = "Subliminal";
            button17.UseVisualStyleBackColor = true;
            button17.Click += button17_Click;
            // 
            // button15
            // 
            button15.Location = new Point(311, 80);
            button15.Name = "button15";
            button15.Size = new Size(62, 23);
            button15.TabIndex = 61;
            button15.Text = "Select";
            button15.UseVisualStyleBackColor = true;
            button15.Click += button15_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(18, 62);
            label9.Name = "label9";
            label9.Size = new Size(68, 15);
            label9.TabIndex = 59;
            label9.Text = "File transfer";
            // 
            // filetxt
            // 
            filetxt.Location = new Point(15, 80);
            filetxt.Name = "filetxt";
            filetxt.Size = new Size(290, 23);
            filetxt.TabIndex = 58;
            // 
            // button13
            // 
            button13.Location = new Point(222, 262);
            button13.Name = "button13";
            button13.Size = new Size(92, 23);
            button13.TabIndex = 54;
            button13.Text = "Subliminal";
            button13.UseVisualStyleBackColor = true;
            button13.Click += button13_Click_1;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(271, 215);
            label6.Name = "label6";
            label6.Size = new Size(67, 15);
            label6.TabIndex = 53;
            label6.Text = "Button Text";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(18, 215);
            label5.Name = "label5";
            label5.Size = new Size(77, 15);
            label5.TabIndex = 52;
            label5.Text = "Message Text";
            // 
            // btnbx
            // 
            btnbx.Location = new Point(271, 233);
            btnbx.Name = "btnbx";
            btnbx.Size = new Size(122, 23);
            btnbx.TabIndex = 51;
            // 
            // msgbx
            // 
            msgbx.Location = new Point(18, 233);
            msgbx.Name = "msgbx";
            msgbx.Size = new Size(241, 23);
            msgbx.TabIndex = 50;
            // 
            // All_chk
            // 
            All_chk.AutoSize = true;
            All_chk.Location = new Point(653, 318);
            All_chk.Name = "All_chk";
            All_chk.Size = new Size(40, 19);
            All_chk.TabIndex = 49;
            All_chk.Text = "All";
            All_chk.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(425, 322);
            label4.Name = "label4";
            label4.Size = new Size(60, 15);
            label4.TabIndex = 48;
            label4.Text = "Username";
            // 
            // button9
            // 
            button9.Location = new Point(697, 320);
            button9.Name = "button9";
            button9.Size = new Size(100, 23);
            button9.TabIndex = 47;
            button9.Text = "Send to";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click_1;
            // 
            // touser
            // 
            touser.Location = new Point(504, 318);
            touser.Name = "touser";
            touser.Size = new Size(143, 23);
            touser.TabIndex = 46;
            // 
            // button8
            // 
            button8.Location = new Point(274, 150);
            button8.Name = "button8";
            button8.Size = new Size(118, 23);
            button8.TabIndex = 45;
            button8.Text = "Pop (Url)";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click_1;
            // 
            // button7
            // 
            button7.Location = new Point(147, 149);
            button7.Name = "button7";
            button7.Size = new Size(118, 23);
            button7.TabIndex = 44;
            button7.Text = "Pop (Download)";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click_1;
            // 
            // button6
            // 
            button6.Location = new Point(623, 274);
            button6.Name = "button6";
            button6.Size = new Size(90, 23);
            button6.TabIndex = 43;
            button6.Text = "To Clipboard";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click_1;
            // 
            // button5
            // 
            button5.Location = new Point(719, 274);
            button5.Name = "button5";
            button5.Size = new Size(75, 23);
            button5.TabIndex = 42;
            button5.Text = "Clear";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click_1;
            // 
            // button4
            // 
            button4.Location = new Point(119, 262);
            button4.Name = "button4";
            button4.Size = new Size(95, 23);
            button4.TabIndex = 41;
            button4.Text = "Message box";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click_1;
            // 
            // button3
            // 
            button3.Location = new Point(507, 274);
            button3.Name = "button3";
            button3.Size = new Size(81, 23);
            button3.TabIndex = 40;
            button3.Text = "Run Input";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click_1;
            // 
            // button2
            // 
            button2.Location = new Point(24, 150);
            button2.Name = "button2";
            button2.Size = new Size(118, 23);
            button2.TabIndex = 39;
            button2.Text = "Open Website";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(512, 13);
            label2.Name = "label2";
            label2.Size = new Size(78, 15);
            label2.TabIndex = 38;
            label2.Text = "Output/Input";
            // 
            // button1
            // 
            button1.Location = new Point(274, 123);
            button1.Name = "button1";
            button1.Size = new Size(118, 23);
            button1.TabIndex = 37;
            button1.Text = "Run File";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // MainTxt
            // 
            MainTxt.Location = new Point(504, 31);
            MainTxt.Multiline = true;
            MainTxt.Name = "MainTxt";
            MainTxt.Size = new Size(290, 237);
            MainTxt.TabIndex = 36;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(18, 13);
            label1.Name = "label1";
            label1.Size = new Size(76, 15);
            label1.TabIndex = 35;
            label1.Text = "Web Address";
            // 
            // ChangeWall_Btn
            // 
            ChangeWall_Btn.Location = new Point(147, 122);
            ChangeWall_Btn.Name = "ChangeWall_Btn";
            ChangeWall_Btn.Size = new Size(118, 23);
            ChangeWall_Btn.TabIndex = 34;
            ChangeWall_Btn.Text = "Change Wallpaper";
            ChangeWall_Btn.UseVisualStyleBackColor = true;
            ChangeWall_Btn.Click += ChangeWall_Btn_Click;
            // 
            // webtxt
            // 
            webtxt.Location = new Point(15, 31);
            webtxt.Name = "webtxt";
            webtxt.Size = new Size(371, 23);
            webtxt.TabIndex = 33;
            // 
            // DownloadFile_Btn
            // 
            DownloadFile_Btn.Location = new Point(24, 121);
            DownloadFile_Btn.Name = "DownloadFile_Btn";
            DownloadFile_Btn.Size = new Size(118, 23);
            DownloadFile_Btn.TabIndex = 32;
            DownloadFile_Btn.Text = "Download File";
            DownloadFile_Btn.UseVisualStyleBackColor = true;
            DownloadFile_Btn.Click += DownloadFile_Btn_Click;
            // 
            // button14
            // 
            button14.Location = new Point(63, 731);
            button14.Name = "button14";
            button14.Size = new Size(75, 23);
            button14.TabIndex = 33;
            button14.Text = "button14";
            button14.UseVisualStyleBackColor = true;
            button14.Click += button14_Click;
            // 
            // openFileDialog1
            // 
            openFileDialog1.FileName = "openFileDialog1";
            // 
            // button16
            // 
            button16.Location = new Point(151, 727);
            button16.Name = "button16";
            button16.Size = new Size(75, 23);
            button16.TabIndex = 34;
            button16.Text = "button16";
            button16.UseVisualStyleBackColor = true;
            button16.Click += button16_Click_1;
            // 
            // button18
            // 
            button18.Location = new Point(267, 731);
            button18.Name = "button18";
            button18.Size = new Size(75, 23);
            button18.TabIndex = 35;
            button18.Text = "button18";
            button18.UseVisualStyleBackColor = true;
            button18.Click += button18_Click;
            // 
            // button19
            // 
            button19.Location = new Point(410, 87);
            button19.Name = "button19";
            button19.Size = new Size(75, 41);
            button19.TabIndex = 76;
            button19.Text = "Send or Delete";
            button19.UseVisualStyleBackColor = true;
            button19.Click += button19_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(868, 501);
            Controls.Add(button18);
            Controls.Add(button16);
            Controls.Add(button14);
            Controls.Add(tabControl1);
            Controls.Add(label3);
            Controls.Add(meuser);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "The Control App v0.993";
            Load += Form1_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private MenuStrip menuStrip1;
        private ToolStripMenuItem settingToolStripMenuItem;
        private ToolStripMenuItem configToolStripMenuItem;
        private TextBox meuser;
        private Label label3;
        private System.Windows.Forms.Timer timer1;
        private ToolStripMenuItem optionsToolStripMenuItem;
        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private Button button13;
        private Label label6;
        private Label label5;
        private TextBox btnbx;
        private TextBox msgbx;
        private CheckBox All_chk;
        private Label label4;
        private Button button9;
        private TextBox touser;
        private Button button8;
        private Button button7;
        private Button button6;
        private Button button5;
        private Button button4;
        private Button button3;
        private Button button2;
        private Label label2;
        private Button button1;
        private TextBox MainTxt;
        private Label label1;
        private Button ChangeWall_Btn;
        private TextBox webtxt;
        private Button DownloadFile_Btn;
        private Button RunNxt;
        private Label label8;
        private TextBox Nocomds;
        private Button button10;
        private Button RptSend;
        private Button button11;
        private Label label9;
        private TextBox filetxt;
        private Button button14;
        private Button button15;
        private OpenFileDialog openFileDialog1;
        private Button button17;
        private Button button12;
        private Button plaudbtn;
        private Button wfmbtn;
        private TextBox wfmtxt;
        private Label label10;
        private Label label7;
        private TextBox wfmnotxt;
        private Button button16;
        private ComboBox groupcmbx;
        private Label label11;
        private Label label12;
        private Label whonxtlbl;
        private Button tkscreen;
        private Button button18;
        private Button ClearOut;
        private Button wtchfrmebtn;
        private Button twitter;
        private Button button19;
    }
}
