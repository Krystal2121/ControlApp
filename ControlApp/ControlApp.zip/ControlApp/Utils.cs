﻿using System.Text;
using System.Configuration;
using Microsoft.Win32;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Diagnostics;
using System.Net;
using System.Media;
using System.IO;
using System.Formats.Tar;
using Microsoft.VisualBasic.ApplicationServices;
using System.Windows.Forms;
using System.Net.Http.Headers;
using System.Security.Policy;
using System.Drawing.Imaging;
using System.Drawing;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace ControlApp
{
    internal class Utils
    {
        public void writetolog(string shortvr, string longvr)
        {
            if (ConfigurationManager.AppSettings["Logging"] == "On")
            {
                if (ConfigurationManager.AppSettings["Logging"] == "On")
                {
                    File.AppendAllText("log.txt", shortvr);
                }
                else { File.AppendAllText("log.txt", longvr); }
            }
        }
        public string[] GetLatestItem()
        {
            string[] ret = { "", "" };
            string senderid = "";
            string user = ConfigurationManager.AppSettings["UserName"].ToString();
            string pwd = ConfigurationManager.AppSettings["Password"].ToString();
            string vrs = "0993";
            string result = getcmd(user, pwd, vrs);


            int sendstart = result.IndexOf("\"SenderId\">");
            if (sendstart > 0)
            {
                int sendend = result.IndexOf("</span>", sendstart);
                if (sendend - (sendstart + 11) >= 0)
                {
                    senderid = result.Substring(sendstart + 11, sendend - (sendstart + 11));
                    if (senderid.Length > 0)
                    {
                        ret[0] = senderid;
                    }
                }
            }

            int start = result.IndexOf("\"Result\">");
            if (start > 0)
            {
                int end = result.IndexOf("</span>", start);
                if (end - (start + 9) >= 0)
                {
                    string fullres = result.Substring(start + 9, end - (start + 9));
                    if (fullres.Length > 3)
                    {
                        ret[1] = fullres;
                        string[] runcode = fullres.Split("|||");
                        try
                        {
                            run_process(runcode, ret[0]);
                        }
                        catch (Exception ex)
                        {
                            writetolog("Error running process \n\r", ex.Message);
                        }
                    }
                }
            }
            return ret;
        }
        public string getcmd(string UserNm, string Pwd, string version)
        {

            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            string downloadString = "";
            try
            {
                using (WebClient client = new WebClient())
                {
                    string geturl = "https://www.thecontrolapp.co.uk/getcontent.aspx?UserNm=" + UserNm + "&Pwd=" + Ecrypt(Pwd) + "&vrs=" + version;
                    downloadString = client.DownloadString(geturl);
                }
            }
            catch (Exception ex)
            {
                writetolog("Error getting command", ex.Message.ToString());
            }
            return downloadString;
        }

        public void sendftpfile(string FileName)
        {
            try
            {
                string justfilename = Path.GetFileName(FileName);
                string ftpUsername = "ftp48810209-0";
                string ftpPassword = "r+LKmTpqO9zzzr5Sdc5rfJMg==";

                using (WebClient client = new WebClient())
                {
                    client.Credentials = new NetworkCredential(ftpUsername, Decrypt(ftpPassword));
                    Uri myuri = new System.Uri("ftp://home240474283.1and1-data.host/ControlMe/Storage/" + justfilename);
                    client.UploadFile(myuri, WebRequestMethods.Ftp.UploadFile, FileName);
                }
            }
            catch (Exception e)
            {
                writetolog("Error sending ftp process \n\r", e.Message);
            }
        }
        public string getftpfile(string FileName)
        {
            string ret = "";
            try
            {
                ret = ConfigurationManager.AppSettings["LocalDrive"] + FileName;
                string ftpUsername = "ftp48810209-0";
                string ftpPassword = "r+LKmTpqO9zzzr5Sdc5rfJMg==";
                using (var client = new WebClient())
                {
                    client.Credentials = new NetworkCredential(ftpUsername, Decrypt(ftpPassword));
                    Uri myuri = new System.Uri("ftp://home240474283.1and1-data.host/ControlMe/Storage/" + FileName);
                    client.DownloadFile(myuri, ret);
                }
                ret = ConfigurationManager.AppSettings["LocalDrive"] + FileName;

            }
            catch (Exception ex)
            {
                writetolog("Error getting ftp \n\r", ex.Message);
            }
            return ret;
        }
        public void deleteoutstanding(string UserNm, string Pwd, string version)
        {
            try
            {
                using (WebClient client = new WebClient())
                {
                    string urlstr = "https://www.thecontrolapp.co.uk/DeleteOut.aspx?UserNm=" + UserNm + "&Pwd=" + Ecrypt(Pwd) + "&vrs=" + version;
                    string res = client.DownloadString(urlstr);
                }
            }
            catch
            { }
        }
        public string[] getoutstanding(string UserNm, string Pwd, string version)
        {
            string[] returned = { "", "" };
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            string downloadString = "";
            try
            {
                using (WebClient client = new WebClient())
                {
                    string urlstr = "https://www.thecontrolapp.co.uk/GetCount.aspx?UserNm=" + UserNm + "&Pwd=" + Ecrypt(Pwd) + "&vrs=" + version;
                    downloadString = client.DownloadString(urlstr);
                }


                int start = downloadString.IndexOf("\"result\">");
                if (start > 0)
                {
                    int end = downloadString.IndexOf("</span>", start);
                    if (end - (start + 9) >= 0)
                    {
                        string fullres = downloadString.Substring(start + 9, end - (start + 9));
                        if (fullres.Length > 0)
                        {
                            returned[0] = fullres;
                        }
                    }
                }
                start = downloadString.IndexOf("\"next\">");
                if (start > 0)
                {
                    int end = downloadString.IndexOf("</span>", start);
                    if (end - (start + 7) >= 0)
                    {
                        string fullres = downloadString.Substring(start + 7, end - (start + 7));
                        if (fullres.Length > 0)
                        {
                            returned[1] = fullres;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                writetolog("Error getting outstanding \n\r", ex.Message);
            }
            return returned;
        }
        public void sendcmd(string UserNm, string comm, bool all)
        {
            string user = ConfigurationManager.AppSettings["UserName"].ToString();
            string pwd = ConfigurationManager.AppSettings["Password"].ToString();
            if (user == null || pwd == null)
            {
                user = "";
                pwd = "";
            }
            int allint = 0;
            if (all) { allint = 1; }
            string what = "https://www.thecontrolapp.co.uk/AppSendContent.aspx?UserNm=" + UserNm + "&comm=" + comm + "&all=" + allint + "&fromuser=" + user + "&frompword=" + Ecrypt(pwd);
            sendcmd sendc = new sendcmd(what);
            sendc.ShowDialog();
        }
        public void SendBlockReport(string senderid, string command, string report)
        {
            string user = ConfigurationManager.AppSettings["UserName"].ToString();
            string pwd = ConfigurationManager.AppSettings["Password"].ToString();
            string what = "https://www.thecontrolapp.co.uk/BlockReport.aspx?usernm=" + user + "&pwd=" + pwd + "&vrs=097&sender=" + senderid + "&report=" + report + "&content=" + command;
            System.Diagnostics.Process.Start(new ProcessStartInfo
            {
                FileName = what,
                UseShellExecute = true
            });
        }
        public string Ecrypt(string Line)
        {
            string ToReturn = "";
            try
            {
                string textToEncrypt = Line;

                string publickey = "santhosh";
                string secretkey = "engineer";
                byte[] secretkeyByte;
                secretkeyByte = System.Text.Encoding.UTF8.GetBytes(secretkey);
                byte[] publickeybyte;
                publickeybyte = System.Text.Encoding.UTF8.GetBytes(publickey);
                MemoryStream ms;
                CryptoStream cs;
                byte[] inputbyteArray = System.Text.Encoding.UTF8.GetBytes(textToEncrypt);
                using (DESCryptoServiceProvider des = new DESCryptoServiceProvider())
                {
                    ms = new MemoryStream();
                    cs = new CryptoStream(ms, des.CreateEncryptor(publickeybyte, secretkeyByte), CryptoStreamMode.Write);
                    cs.Write(inputbyteArray, 0, inputbyteArray.Length);
                    cs.FlushFinalBlock();
                    ToReturn = Convert.ToBase64String(ms.ToArray());
                }
                ToReturn = ToReturn.Replace("\\", "xxx");
                ToReturn = ToReturn.Replace("&", "yyy");
                ToReturn = ToReturn.Replace("/", "zzz");
                ToReturn = ToReturn.Replace("]", "aaa");

            }
            catch (Exception ex)
            {
                writetolog("Error enrypt " + Line + "\n\r", ex.Message);
            }
            return ToReturn;
        }
        public string Decrypt(string Line)
        {
            string ToReturn = "";
            try
            {

                Line = Line.Replace("xxx", "\\");
                Line = Line.Replace("yyy", "&");
                Line = Line.Replace("zzz", "/");
                Line = Line.Replace("aaa", "]");

                string publickey = "santhosh";
                string privatekey = "engineer";
                byte[] privatekeyByte = System.Text.Encoding.UTF8.GetBytes(privatekey);
                byte[] publickeybyte = System.Text.Encoding.UTF8.GetBytes(publickey);
                MemoryStream ms = null;
                CryptoStream cs = null;
                byte[] inputbyteArray = new byte[Line.Replace(" ", "+").Length];
                inputbyteArray = Convert.FromBase64String(Line.Replace(" ", "+"));
                using (DESCryptoServiceProvider des = new DESCryptoServiceProvider())
                {
                    ms = new MemoryStream();
                    cs = new CryptoStream(ms, des.CreateDecryptor(publickeybyte, privatekeyByte), CryptoStreamMode.Write);
                    cs.Write(inputbyteArray, 0, inputbyteArray.Length);
                    cs.FlushFinalBlock();
                    Encoding encoding = Encoding.UTF8;
                    ToReturn = encoding.GetString(ms.ToArray());
                }
            }
            catch (Exception ex)
            {
                writetolog("Decrypt error for : " + Line + "\n\r", ex.Message);
            }
            return ToReturn;
        }
        public string Get_File(string url)
        {
            string filename = "";
            string directory = url.Substring(0, url.LastIndexOf('/'));
            filename = url.Substring(url.LastIndexOf("/") + 1, (url.Length - url.LastIndexOf("/")) - 1);
            filename = ConfigurationManager.AppSettings["LocalDrive"] + filename;
            filename.Replace(".webp", "");
            try
            {
                HttpClient client = new HttpClient();
                Task<Stream> s = client.GetStreamAsync(url);
                FileStream fs = new FileStream(filename, FileMode.Create);
                s.Result.CopyTo(fs);
                fs.Close();
                s.Dispose();
                client.Dispose();
            }
            catch (Exception ex)
            {
                writetolog("Error getting file for : " + url + "\n\r", ex.Message);
            }
            return filename;
        }

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        static extern int SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);

        const int SPI_SETDESKWALLPAPER = 20;
        const int SPIF_UPDATEINIFILE = 0x01;
        const int SPIF_SENDWININICHANGE = 0x02;
        string[] bannedlist = { "booru.allthefallen.moe" };

        public void Change_Wallpaper(string filename)
        {
            string style = ConfigurationManager.AppSettings["PaperStyle"];
            RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Control Panel\Desktop", true);
            if (key != null)
            {
                if (style == "Stretch")
                {
                    key.SetValue(@"WallpaperStyle", 2.ToString());
                    key.SetValue(@"TileWallpaper", 0.ToString());
                }

                if (style == "Fit")
                {
                    key.SetValue(@"WallpaperStyle", 1.ToString());
                    key.SetValue(@"TileWallpaper", 0.ToString());
                }

                SystemParametersInfo(SPI_SETDESKWALLPAPER, 0, filename, SPIF_UPDATEINIFILE | SPIF_SENDWININICHANGE);
            }
        }

        public void run_process(string[] lines, string from)
        {

            if (lines.Length > 0)
                SystemSounds.Beep.Play();
            foreach (string line in lines)
            {
                if (line == "")
                    break;
                string decrip = Decrypt(line);
                writetolog(line + "\n", line + "\n");
                if (decrip.Length > 2)
                {
                    try
                    {
                        string which = decrip.Substring(0, 2);
                        string what = decrip.Substring(2, decrip.Length - 2).Trim();
                        bool inbanned = false;
                        foreach (string banned in bannedlist)
                        {
                            if (what.Contains(banned))
                                inbanned = true;
                        }
                        if (inbanned)
                        {
                            CustomMessage cm = new CustomMessage("Message contains potential bad stuff closing", "", 4);
                            cm.ShowDialog();
                            break;
                        }
                        bool isftp = false;
                        if (what.Substring(0, 3) == "FTP") isftp = true;
                        if (isftp)
                        {
                            what = getftpfile(what.Substring(3, what.Length - 3));
                        }
                        string type = "";
                        try
                        {
                            type = what.Substring(what.Length - 5, 5);
                        }
                        catch { }
                        bool isfile = false;
                        if (type.IndexOf('.') >= 0)
                        {
                            isfile = true;
                        }
                        if (which == "D=")
                        {
                            if (ConfigurationManager.AppSettings["Downloads"] == null || !Convert.ToBoolean(ConfigurationManager.AppSettings["Downloads"].ToString()))
                            {
                                string thefile = "";
                                if (!isfile)
                                {
                                    System.Diagnostics.Process.Start(new ProcessStartInfo
                                    {
                                        FileName = what,
                                        UseShellExecute = true
                                    });
                                }
                                else
                                {
                                    if (!isftp)
                                    {
                                        thefile = Get_File(what);
                                    }
                                    else
                                        thefile = what;
                                }
                                CustomMessage cm = new CustomMessage("File downloaded! Find it here : " + thefile, "", 4);
                                cm.ShowDialog();
                            }
                            else
                            {
                                if (ConfigurationManager.AppSettings["Showblocked"] != null && ConfigurationManager.AppSettings["Showblocked"] == "True")
                                {
                                    CustomMessage cm = new CustomMessage("Download blocked", "", 4);
                                    cm.ShowDialog();
                                }
                            }
                        }
                        else
                        if (which == "P=")
                        {
                            if (ConfigurationManager.AppSettings["Wallpapers"] == null || !Convert.ToBoolean(ConfigurationManager.AppSettings["Wallpapers"].ToString()))
                            {
                                if (!isfile)
                                {
                                    System.Diagnostics.Process.Start(new ProcessStartInfo
                                    {
                                        FileName = what,
                                        UseShellExecute = true
                                    });
                                }
                                else
                                {
                                    string thefile = "";
                                    if (!isftp)
                                    {
                                        thefile = Get_File(what);
                                    }
                                    else
                                        thefile = what;
                                    Change_Wallpaper(thefile);
                                }
                            }
                            else
                            {
                                if (ConfigurationManager.AppSettings["Showblocked"] != null && ConfigurationManager.AppSettings["Showblocked"] == "True")
                                {
                                    CustomMessage cm = new CustomMessage("Wallpaper blocked", "", 4);
                                    cm.ShowDialog();
                                }
                            }
                        }
                        else
                        if (which == "R=")
                        {
                            if (ConfigurationManager.AppSettings["Runables"] == null || !Convert.ToBoolean(ConfigurationManager.AppSettings["Runables"].ToString()))
                            {
                                if ((!isfile) || ((what.Length > 4) && (what.Substring(what.Length - 3, 3) != "exe") && (what.Substring(what.Length - 3, 3) != "bat")))
                                {
                                    System.Diagnostics.Process.Start(new ProcessStartInfo
                                    {
                                        FileName = what,
                                        UseShellExecute = true
                                    });
                                }
                                else
                                {
                                    string thefile = "";
                                    if (!isftp)
                                    {
                                        thefile = Get_File(what);
                                    }
                                    else
                                        thefile = what;
                                    if (ConfigurationManager.AppSettings["AutoRun"] == "True")
                                        Process.Start(thefile);
                                    else
                                    {
                                        CustomMessage cm = new CustomMessage("Exe downloaded! Find it here : " + thefile, "", 4);
                                        cm.ShowDialog();
                                    }
                                }

                            }
                            else
                            {
                                if (ConfigurationManager.AppSettings["Showblocked"] != null && ConfigurationManager.AppSettings["Showblocked"] == "True")
                                {
                                    CustomMessage cm = new CustomMessage("Exe blocked", "", 4);
                                    cm.ShowDialog();
                                }
                            }
                        }
                        else
                        if (which == "W=")
                        {
                            if (ConfigurationManager.AppSettings["OpenWeb"] == null || !Convert.ToBoolean(ConfigurationManager.AppSettings["OpenWeb"].ToString()))
                            {
                                System.Diagnostics.Process.Start(new ProcessStartInfo
                                {
                                    FileName = what,
                                    UseShellExecute = true
                                });
                            }
                            else
                            {
                                if (ConfigurationManager.AppSettings["Showblocked"] != null && ConfigurationManager.AppSettings["Showblocked"] == "True")
                                {
                                    CustomMessage cm = new CustomMessage("Website blocked", "", 4);
                                    cm.ShowDialog();
                                }
                            }
                        }
                        else
                        if ((which == "U=") || (which == "O=" && what.IndexOf("static") > 0))
                        {
                            if (ConfigurationManager.AppSettings["PopUps"] == null || !Convert.ToBoolean(ConfigurationManager.AppSettings["PopUps"].ToString()))
                            {
                                if (!isfile)
                                {
                                    System.Diagnostics.Process.Start(new ProcessStartInfo
                                    {
                                        FileName = what,
                                        UseShellExecute = true
                                    });
                                }
                                else
                                {
                                    string thefile = "";
                                    if (!isftp)
                                    {
                                        thefile = Get_File(what);
                                    }
                                    else
                                        thefile = what;
                                    string popstyle = "Serial";
                                    if (ConfigurationManager.AppSettings["PopStyle"] != null)
                                        popstyle = ConfigurationManager.AppSettings["PopStyle"].ToString();
                                    if (popstyle == "Serial")
                                    {
                                        bool done = false;
                                        foreach (Form fm in Application.OpenForms)
                                        {
                                            if (fm.GetType() == typeof(PopUp))
                                            {
                                                PopUp pop = (PopUp)fm;
                                                pop.add_url(thefile);
                                                done = true;
                                            }
                                        }
                                        if (!done)
                                        {
                                            PopUp pop = new PopUp(thefile);
                                            pop.Show();
                                        }
                                    }
                                    else
                                    {
                                        PopUp pop = new PopUp(thefile);
                                        pop.Show();
                                    }
                                }
                            }
                            else
                            {
                                if (ConfigurationManager.AppSettings["Showblocked"] != null && ConfigurationManager.AppSettings["Showblocked"] == "True")
                                {
                                    CustomMessage cm = new CustomMessage("Popup blocked", "", 4);
                                    cm.ShowDialog();
                                }
                            }
                        }
                        else
                        if (which == "O=" && what.IndexOf("static") == -1)
                        {
                            if (ConfigurationManager.AppSettings["PopUps"] == null || !Convert.ToBoolean(ConfigurationManager.AppSettings["PopUps"].ToString()))
                            {
                                if (!isfile)
                                {
                                    System.Diagnostics.Process.Start(new ProcessStartInfo
                                    {
                                        FileName = what,
                                        UseShellExecute = true
                                    });
                                }
                                else
                                {
                                    string popstyle = "Serial";
                                    if (ConfigurationManager.AppSettings["PopStyle"] != null)
                                        popstyle = ConfigurationManager.AppSettings["PopStyle"].ToString();
                                    if (popstyle == "Serial")
                                    {
                                        bool done = false;
                                        foreach (Form fm in Application.OpenForms)
                                        {
                                            if (fm.GetType() == typeof(PopUp))
                                            {
                                                PopUp pop = (PopUp)fm;
                                                pop.add_url(what);
                                                done = true;
                                            }
                                        }
                                        if (!done)
                                        {
                                            PopUp pop = new PopUp(what);
                                            pop.Show();
                                        }
                                    }
                                    else
                                    {
                                        PopUp pop = new PopUp(what);
                                        pop.Show();
                                    }
                                }
                            }
                            else
                            {
                                if (ConfigurationManager.AppSettings["Showblocked"] != null && ConfigurationManager.AppSettings["Showblocked"] == "True")
                                {
                                    CustomMessage cm = new CustomMessage("popup blocked", "", 4);
                                    cm.ShowDialog();
                                }
                            }
                        }
                        else
                        if (which == "M=")
                        {
                            if (ConfigurationManager.AppSettings["Messages"] == null || !Convert.ToBoolean(ConfigurationManager.AppSettings["Messages"].ToString()))
                            {
                                string[] split = what.Split("&&&");
                                CustomMessage cm;
                                if (split.Length > 1)
                                {
                                    cm = new CustomMessage(split[0], split[1], 0);
                                }
                                else { cm = new CustomMessage(split[0], "", 0); }
                                cm.ShowDialog();
                            }
                            else
                            {
                                if (ConfigurationManager.AppSettings["Showblocked"] != null && ConfigurationManager.AppSettings["Showblocked"] == "True")
                                {
                                    CustomMessage cm = new CustomMessage("Message blocked", "", 4);
                                    cm.ShowDialog();
                                }
                            }
                        }
                        else
                        if (which == "S=")
                        {
                            if (ConfigurationManager.AppSettings["Subliminals"] == null || !Convert.ToBoolean(ConfigurationManager.AppSettings["Subliminals"].ToString()))
                            {
                                if (!isfile)
                                {
                                    System.Diagnostics.Process.Start(new ProcessStartInfo
                                    {
                                        FileName = what,
                                        UseShellExecute = true
                                    });
                                }
                                else
                                {
                                    string thefile = "";
                                    if (!isftp)
                                    {
                                        thefile = Get_File(what);
                                    }
                                    else
                                        thefile = what;
                                    Subliminal subliminal = new Subliminal(thefile, false);
                                }
                            }
                            else
                            {
                                if (ConfigurationManager.AppSettings["Showblocked"] != null && ConfigurationManager.AppSettings["Showblocked"] == "True")
                                {
                                    CustomMessage cm = new CustomMessage("Subliminal blocked", "", 4);
                                    cm.ShowDialog();
                                }
                            }
                        }
                        else
                        if (which == "V=")
                        {
                            if (ConfigurationManager.AppSettings["Subliminals"] == null || !Convert.ToBoolean(ConfigurationManager.AppSettings["Subliminals"].ToString()))
                            {
                                Subliminal subliminal = new Subliminal(what, true);
                            }
                            else
                            {
                                if (ConfigurationManager.AppSettings["Showblocked"] != null && ConfigurationManager.AppSettings["Showblocked"] == "True")
                                {
                                    CustomMessage cm = new CustomMessage("Subliminal blocked", "", 4);
                                    cm.ShowDialog();
                                }
                            }
                        }
                        else
                            if (which == "A=")
                        {
                            if (ConfigurationManager.AppSettings["Audios"] == null || !Convert.ToBoolean(ConfigurationManager.AppSettings["Audios"].ToString()))
                            {
                                if (!isfile)
                                {
                                    System.Diagnostics.Process.Start(new ProcessStartInfo
                                    {
                                        FileName = what,
                                        UseShellExecute = true
                                    });
                                }
                                else
                                {
                                    string thefile = "";
                                    if (!isftp)
                                    {
                                        thefile = Get_File(what);
                                    }
                                    else
                                        thefile = what;
                                    Audiopop aud = new Audiopop(thefile);
                                    aud.ShowDialog();
                                }
                            }
                            else
                            {
                                if (ConfigurationManager.AppSettings["Showblocked"] != null && ConfigurationManager.AppSettings["Showblocked"] == "True")
                                {
                                    CustomMessage cm = new CustomMessage("Audio blocked", "", 4);
                                    cm.ShowDialog();
                                }
                            }
                        }
                        else
                            if (which == "F=")
                        {
                            if (ConfigurationManager.AppSettings["Writeformes"] == null || !Convert.ToBoolean(ConfigurationManager.AppSettings["Writeformes"].ToString()))
                            {
                                string[] split = what.Split("&&&");
                                WriteForMe wfm;
                                wfm = new WriteForMe(split[0], split[1], from);
                                wfm.ShowDialog();
                            }
                            else
                            {
                                if (ConfigurationManager.AppSettings["Showblocked"] != null && ConfigurationManager.AppSettings["Showblocked"] == "True")
                                {
                                    CustomMessage cm = new CustomMessage("Writeforme blocked", "", 4);
                                    cm.ShowDialog();
                                }
                            }
                        }
                        else
                            if (which == "1=")
                        {
                            if (what == "Yes")
                                if (ConfigurationManager.AppSettings["ScreenShots"] == null || !Convert.ToBoolean(ConfigurationManager.AppSettings["ScreenShots"].ToString()))
                                {
                                    string filename = "scr" + ConfigurationManager.AppSettings["UserName"].ToString() + DateTime.Now.Date.ToString().Replace("/", "").Replace(" ", "").Replace(":", "") + ".jpg";
                                    string filePath = ConfigurationManager.AppSettings["LocalDrive"] + filename;
                                    using (Bitmap bmpScreenCapture = new Bitmap(Screen.PrimaryScreen.Bounds.Width,
                                                Screen.PrimaryScreen.Bounds.Height))
                                    {
                                        using (Graphics g = Graphics.FromImage(bmpScreenCapture))
                                        {
                                            g.CopyFromScreen(Screen.PrimaryScreen.Bounds.X,
                                                             Screen.PrimaryScreen.Bounds.Y,
                                                             0, 0,
                                                             bmpScreenCapture.Size,
                                                             CopyPixelOperation.SourceCopy);
                                        }
                                        bmpScreenCapture.Save(filePath, ImageFormat.Jpeg);
                                    }
                                    sendftpfile(filePath);
                                    sendcmd(from, Ecrypt("U=FTP" + filename) + "|||", false);
                                    MessageBox.Show("Screen shot taken :D");
                                }
                                else
                                {
                                    if (ConfigurationManager.AppSettings["Showblocked"] != null && ConfigurationManager.AppSettings["Showblocked"] == "True")
                                    {
                                        CustomMessage cm = new CustomMessage("screenshot blocked", "", 4);
                                        cm.ShowDialog();
                                    }
                                }
                        }
                        else if (which == "2=")
                        {
                            if (ConfigurationManager.AppSettings["Watch4me"] == null || !Convert.ToBoolean(ConfigurationManager.AppSettings["Watch4me"].ToString()))
                            {
                                WatchForMe wfm = new WatchForMe(what, from);
                                wfm.Show();
                            }
                            else
                            {
                                if (ConfigurationManager.AppSettings["Showblocked"] != null && ConfigurationManager.AppSettings["Showblocked"] == "True")
                                {
                                    CustomMessage cm = new CustomMessage("watchforme blocked", "", 4);
                                    cm.ShowDialog();
                                }
                            }
                        }
                        else if (which == "3=")
                        {
                            if (ConfigurationManager.AppSettings["twitter"] == null || !Convert.ToBoolean(ConfigurationManager.AppSettings["twitter"].ToString()))
                            {
                                what = what.Replace(" ", "%20");
                                System.Diagnostics.Process.Start(new ProcessStartInfo
                                {
                                    FileName = "https://twitter.com/intent/tweet?text=" + what + " [Posted by :]&url=www.thecontrolapp.co.uk",
                                    UseShellExecute = true
                                });
                            }
                            else
                            {
                                if (ConfigurationManager.AppSettings["Showblocked"] != null && ConfigurationManager.AppSettings["Showblocked"] == "True")
                                {
                                    CustomMessage cm = new CustomMessage("twitter blocked", "", 4);
                                    cm.ShowDialog();
                                }
                            }

                        }
                        else
                            if (which == "4=")
                        {
                            if (what == "Yes")
                                if (ConfigurationManager.AppSettings["SendDelete"] == null || !Convert.ToBoolean(ConfigurationManager.AppSettings["SendDelete"].ToString()))
                                {
                                    SendOrDelete sod = new SendOrDelete(from);
                                    sod.Show();
                                }
                                else
                                {
                                    if (ConfigurationManager.AppSettings["Showblocked"]!=null && ConfigurationManager.AppSettings["Showblocked"] == "True")
                                    {
                                        CustomMessage cm = new CustomMessage("Send delete blocked", "", 4);
                                        cm.ShowDialog();
                                    }
                                }
                        }
                    }
                    catch (Exception e)
                    {
                        writetolog("Error proccessing for : " + line + "\n\r", e.Message);
                    }
                }
            }
        }

    }
}
