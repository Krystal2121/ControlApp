﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControlApp
{
    public partial class CustomMessage : Form
    {
        string msg;
        string btn;
        private System.Windows.Forms.Timer tmr;
        public CustomMessage(string message, string button, int timeopen)
        {
            InitializeComponent();
            msg = message;
            btn = button;
            label1.Text = msg;
            if (btn != "")
            {
                button1.Text = btn;
            }
            if (timeopen != 0)
            {
                tmr = new System.Windows.Forms.Timer();
                tmr.Tick += delegate
                {
                    this.Close();
                };

                tmr.Interval = (int)TimeSpan.FromSeconds(timeopen).TotalMilliseconds;

                tmr.Start();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CustomMessage_Load(object sender, EventArgs e)
        {

        }
    }
}
