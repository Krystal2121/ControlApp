﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControlApp
{
    public partial class PopUp : Form
    {
        public string run_url;
        private System.Windows.Forms.Timer tmr;

        const int GWL_STYLE = (-20);

        const UInt32 WS_POPUP = 0x80000000;
        const UInt32 WS_CHILD = 0x20000000;

        [DllImport("user32.dll", SetLastError = true)]
        static extern UInt32 GetWindowLong(IntPtr hWnd, int nIndex);

        [DllImport("user32.dll")]
        static extern int SetWindowLong(IntPtr hWnd, int nIndex, UInt32 dwNewLong);

        List<string> urls;
        public PopUp(string url)
        {
            urls = new List<string>();  
            InitializeComponent();
            if (ConfigurationManager.AppSettings["Clickthroughpop"]=="True")
            {
                this.Opacity = .5;
                // Set the form click-through
                UInt32 initialStyle = GetWindowLong(this.Handle, -20);
                SetWindowLong(this.Handle, -20, initialStyle | 0x80000 | 0x20);
                
            }
            run_url = url;
            string last3 = run_url.Substring(run_url.Length - 3, 3);
            if ((last3 == "com") || (last3 == ".uk") || (last3 == "org"))
            {
                System.Diagnostics.Process.Start(new ProcessStartInfo
                {
                    FileName = url,
                    UseShellExecute = true
                });
                this.Close();
            }
            tmr = new System.Windows.Forms.Timer();
            tmr.Tick += popup_tick;
            Random rand = new Random();
            if ((ConfigurationManager.AppSettings["PopSet"] != null) && ("Long" == ConfigurationManager.AppSettings["PopSet"].ToString()))
            {
                int mins = rand.Next(11);
                tmr.Interval = (int)TimeSpan.FromMinutes(mins).TotalMilliseconds;
            }
            else
            {
                int mins = rand.Next(55) + 5;
                tmr.Interval = (int)TimeSpan.FromSeconds(mins).TotalMilliseconds;
            }
            tmr.Start();
        }
        public void add_url(string url)
        {
            urls.Add(url);
        }
        public void popup_tick(object sender, EventArgs e)
        {
            if (urls.Count > 0)
            {
                run_url = urls[0];
                urls.RemoveAt(0);
                axWindowsMediaPlayer1.URL = run_url;
                axWindowsMediaPlayer1.Ctlenabled = false;
                axWindowsMediaPlayer1.uiMode = "None";
                axWindowsMediaPlayer1.settings.autoStart = true;
                axWindowsMediaPlayer1.settings.setMode("loop", true);
            }
            else
            {
                this.Close();
            }
        }
        private void PopUp_Load(object sender, EventArgs e)
        {
            Random random = new Random(); 
            int screenWidth = Screen.PrimaryScreen.Bounds.Width; 
            int screenHeight = Screen.PrimaryScreen.Bounds.Height; 
            int randomX = random.Next(0, screenWidth - this.Width); 
            int randomY = random.Next(0, screenHeight - this.Height); 
            this.StartPosition = FormStartPosition.Manual; 
            this.Location = new Point(randomX, randomY);

            axWindowsMediaPlayer1.URL = run_url;
            axWindowsMediaPlayer1.Ctlenabled = false;
            axWindowsMediaPlayer1.uiMode = "None";
            axWindowsMediaPlayer1.settings.autoStart = true;
            axWindowsMediaPlayer1.settings.setMode("loop", true);

        }
    }
}
