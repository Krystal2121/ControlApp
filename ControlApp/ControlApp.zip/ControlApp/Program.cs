using System.Configuration;
using System.Resources;

namespace ControlApp
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Application.Run(new MyCustomApplicationContext());
        }
    }


    public class MyCustomApplicationContext : ApplicationContext
    {
        private NotifyIcon trayIcon;

        public MyCustomApplicationContext()
        {
            // Initialize Tray Icon
            trayIcon = new NotifyIcon();
            trayIcon.Icon = new Icon("App.ico");
            trayIcon.ContextMenuStrip = new ContextMenuStrip();
            trayIcon.ContextMenuStrip.Items.Add("Exit",null, Exit);
            trayIcon.ContextMenuStrip.Items.Add("Open",null, Open);
            trayIcon.ContextMenuStrip.Items.Add("Panic", null, Panic);
            trayIcon.Visible = true;
        }

        void Exit(object sender, EventArgs e)
        {
            // Hide tray icon, otherwise it will remain shown until user mouses over it
            trayIcon.Visible = false;

            Application.Exit();
        }
        void Open(object sender, EventArgs e)
        {
            // Hide tray icon, otherwise it will remain shown until user mouses over it
            Form1 myform =new Form1();
            myform.ShowDialog();
        }
        void Panic(object sender, EventArgs e)
        {
            foreach(Form fm in Application.OpenForms)
            {
                fm.Close();
                Utils utils = new Utils();
                utils.sendcmd("-11", utils.Ecrypt("M=" + ConfigurationManager.AppSettings["UserName"].ToString() + " panicked and shut down their windows."), true);
            }
        }
    }
}