﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
using AxWMPLib;
using static System.Net.Mime.MediaTypeNames;
using System.Reflection.Emit;
using System.Configuration;

namespace ControlApp
{
    public partial class WatchForMe : Form
    {
        string senderstr;
        public WatchForMe(string Url,string senderid)
        {
            senderstr = senderid;
            InitializeComponent();
            string filetype = Path.GetExtension(Url);
            if ((filetype == ".mp4") || (filetype == ".webm") ||(filetype==".webp") || (filetype == ".gif"))
            {
                axWindowsMediaPlayer1.URL = Url;
                axWindowsMediaPlayer1.Ctlenabled = false;
                axWindowsMediaPlayer1.uiMode = "None";
                axWindowsMediaPlayer1.settings.autoStart = true;
                axWindowsMediaPlayer1.settings.setMode("loop", true);
            }
            else if ((filetype == ".png") || (filetype == ".jpg") || (filetype == ".jepg"))
            {
                System.Drawing.Image i = System.Drawing.Image.FromFile(Url);
                Screen my = Screen.AllScreens[0];
                if (i.Width > my.Bounds.Width)
                    this.Width = my.Bounds.Width;
                else
                    this.Width = i.Width;

                if (i.Height > my.Bounds.Height)
                    this.Height = my.Bounds.Height;
                else
                    this.Height = i.Height;

                axWindowsMediaPlayer1.Visible = false;
                PictureBox pictureBox = new PictureBox()
                {
                    Dock = DockStyle.Fill,
                    Image = i
                };
                Controls.Add(pictureBox);
            }
            else
            {
                axWindowsMediaPlayer1.Visible = false;
                WebBrowser wb = new WebBrowser();
                {
                    wb.Navigate(Url);
                    wb.Dock = DockStyle.Fill;
                    wb.ScriptErrorsSuppressed= true;
                }
                Controls.Add(wb);
            }
            this.AutoSize = true;
            timewatched = 0;
            losefocus = 0;
            timer1.Interval = 1000; // Set the timer interval to 1 second
                           timer1.Tick += new EventHandler(Timer1_Tick); 
            timer1.Start();
            isdeactive = false;
            this.Deactivate += new EventHandler(Form1_Deactivate);
            this.Activated += new EventHandler(Form1_Reactivate);
            this.FormClosing += new FormClosingEventHandler(Form1_FormClosing);
        }
        int timewatched;
        bool isdeactive;
        int losefocus;
        private void WatchForMe_Load(object sender, EventArgs e)
        {

        }
        private void Timer1_Tick(object sender, EventArgs e) 
        {
            if (!isdeactive)
            {
                timewatched++;
                this.Text = "Watch for me Time=" + timewatched.ToString()+" Lost focus="+losefocus.ToString();
            }
        }
        private void Form1_Deactivate(object sender, EventArgs e)
        {
            losefocus++;
            isdeactive = true;
        }
        private void Form1_Reactivate(object sender, EventArgs e)
        {
            if (isdeactive)
            {
                isdeactive = false;
            }
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e) 
        { 
            if (e.CloseReason == CloseReason.UserClosing) 
            {
                string usrnm = ConfigurationManager.AppSettings["UserName"].ToString();
                Utils utils = new Utils();
                utils.sendcmd(senderstr, utils.Ecrypt("M=User : " + usrnm + " Watched for : " + timewatched.ToString() + " seconds. Form lost focus :" + losefocus.ToString() + " times"),false);
            } 
        }
    }
}
