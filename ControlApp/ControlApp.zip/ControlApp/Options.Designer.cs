﻿namespace ControlApp
{
    partial class Options
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Popups = new Panel();
            longpop = new RadioButton();
            shortpop = new RadioButton();
            label1 = new Label();
            SvExit = new Button();
            panel1 = new Panel();
            watch4mech = new CheckBox();
            twitch = new CheckBox();
            screenshch = new CheckBox();
            wrich = new CheckBox();
            audioch = new CheckBox();
            sublimch = new CheckBox();
            messch = new CheckBox();
            popch = new CheckBox();
            label2 = new Label();
            opwebch = new CheckBox();
            runch = new CheckBox();
            wallpch = new CheckBox();
            dlch = new CheckBox();
            panel2 = new Panel();
            fitsc = new RadioButton();
            stret = new RadioButton();
            label3 = new Label();
            panel3 = new Panel();
            parallelrd = new RadioButton();
            serialrd = new RadioButton();
            label4 = new Label();
            senddelch = new CheckBox();
            Popups.SuspendLayout();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            SuspendLayout();
            // 
            // Popups
            // 
            Popups.Controls.Add(longpop);
            Popups.Controls.Add(shortpop);
            Popups.Controls.Add(label1);
            Popups.Location = new Point(10, 12);
            Popups.Name = "Popups";
            Popups.Size = new Size(334, 77);
            Popups.TabIndex = 0;
            // 
            // longpop
            // 
            longpop.AutoSize = true;
            longpop.Location = new Point(12, 43);
            longpop.Name = "longpop";
            longpop.Size = new Size(185, 19);
            longpop.TabIndex = 2;
            longpop.TabStop = true;
            longpop.Text = "Long popups (1min - 10 mins)";
            longpop.UseVisualStyleBackColor = true;
            // 
            // shortpop
            // 
            shortpop.AutoSize = true;
            shortpop.Location = new Point(12, 18);
            shortpop.Name = "shortpop";
            shortpop.Size = new Size(174, 19);
            shortpop.TabIndex = 1;
            shortpop.TabStop = true;
            shortpop.Text = "Short popups (10sec - 1min)";
            shortpop.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(3, 0);
            label1.Name = "label1";
            label1.Size = new Size(47, 15);
            label1.TabIndex = 0;
            label1.Text = "Popups";
            // 
            // SvExit
            // 
            SvExit.Location = new Point(126, 436);
            SvExit.Name = "SvExit";
            SvExit.Size = new Size(81, 23);
            SvExit.TabIndex = 1;
            SvExit.Text = "Save & Exit ";
            SvExit.UseVisualStyleBackColor = true;
            SvExit.Click += SvExit_Click;
            // 
            // panel1
            // 
            panel1.Controls.Add(senddelch);
            panel1.Controls.Add(watch4mech);
            panel1.Controls.Add(twitch);
            panel1.Controls.Add(screenshch);
            panel1.Controls.Add(wrich);
            panel1.Controls.Add(audioch);
            panel1.Controls.Add(sublimch);
            panel1.Controls.Add(messch);
            panel1.Controls.Add(popch);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(opwebch);
            panel1.Controls.Add(runch);
            panel1.Controls.Add(wallpch);
            panel1.Controls.Add(dlch);
            panel1.Location = new Point(10, 100);
            panel1.Name = "panel1";
            panel1.Size = new Size(334, 276);
            panel1.TabIndex = 2;
            // 
            // watch4mech
            // 
            watch4mech.AutoSize = true;
            watch4mech.Location = new Point(122, 85);
            watch4mech.Name = "watch4mech";
            watch4mech.Size = new Size(98, 19);
            watch4mech.TabIndex = 12;
            watch4mech.Text = "Watch for me";
            watch4mech.UseVisualStyleBackColor = true;
            // 
            // twitch
            // 
            twitch.AutoSize = true;
            twitch.Location = new Point(122, 60);
            twitch.Name = "twitch";
            twitch.Size = new Size(87, 19);
            twitch.TabIndex = 11;
            twitch.Text = "Twitter post";
            twitch.UseVisualStyleBackColor = true;
            // 
            // screenshch
            // 
            screenshch.AutoSize = true;
            screenshch.Location = new Point(122, 35);
            screenshch.Name = "screenshch";
            screenshch.Size = new Size(92, 19);
            screenshch.TabIndex = 10;
            screenshch.Text = "Screen shots";
            screenshch.UseVisualStyleBackColor = true;
            // 
            // wrich
            // 
            wrich.AutoSize = true;
            wrich.Location = new Point(12, 234);
            wrich.Name = "wrich";
            wrich.Size = new Size(92, 19);
            wrich.TabIndex = 9;
            wrich.Text = "Write for me";
            wrich.UseVisualStyleBackColor = true;
            // 
            // audioch
            // 
            audioch.AutoSize = true;
            audioch.Location = new Point(12, 209);
            audioch.Name = "audioch";
            audioch.Size = new Size(58, 19);
            audioch.TabIndex = 8;
            audioch.Text = "Audio";
            audioch.UseVisualStyleBackColor = true;
            // 
            // sublimch
            // 
            sublimch.AutoSize = true;
            sublimch.Location = new Point(12, 185);
            sublimch.Name = "sublimch";
            sublimch.Size = new Size(82, 19);
            sublimch.TabIndex = 7;
            sublimch.Text = "Subliminal";
            sublimch.UseVisualStyleBackColor = true;
            // 
            // messch
            // 
            messch.AutoSize = true;
            messch.Location = new Point(12, 160);
            messch.Name = "messch";
            messch.Size = new Size(77, 19);
            messch.TabIndex = 6;
            messch.Text = "Messages";
            messch.UseVisualStyleBackColor = true;
            // 
            // popch
            // 
            popch.AutoSize = true;
            popch.Location = new Point(12, 135);
            popch.Name = "popch";
            popch.Size = new Size(70, 19);
            popch.TabIndex = 5;
            popch.Text = "Pop Ups";
            popch.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 0);
            label2.Name = "label2";
            label2.Size = new Size(56, 15);
            label2.TabIndex = 4;
            label2.Text = "Dis-allow";
            // 
            // opwebch
            // 
            opwebch.AutoSize = true;
            opwebch.Location = new Point(12, 110);
            opwebch.Name = "opwebch";
            opwebch.Size = new Size(100, 19);
            opwebch.TabIndex = 3;
            opwebch.Text = "Open Website";
            opwebch.UseVisualStyleBackColor = true;
            // 
            // runch
            // 
            runch.AutoSize = true;
            runch.Location = new Point(12, 85);
            runch.Name = "runch";
            runch.Size = new Size(93, 19);
            runch.TabIndex = 2;
            runch.Text = "Runable files";
            runch.UseVisualStyleBackColor = true;
            // 
            // wallpch
            // 
            wallpch.AutoSize = true;
            wallpch.Location = new Point(12, 60);
            wallpch.Name = "wallpch";
            wallpch.Size = new Size(79, 19);
            wallpch.TabIndex = 1;
            wallpch.Text = "Wallpaper";
            wallpch.UseVisualStyleBackColor = true;
            // 
            // dlch
            // 
            dlch.AutoSize = true;
            dlch.Location = new Point(12, 35);
            dlch.Name = "dlch";
            dlch.Size = new Size(80, 19);
            dlch.TabIndex = 0;
            dlch.Text = "Download";
            dlch.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            panel2.Controls.Add(fitsc);
            panel2.Controls.Add(stret);
            panel2.Controls.Add(label3);
            panel2.Location = new Point(10, 382);
            panel2.Name = "panel2";
            panel2.Size = new Size(334, 48);
            panel2.TabIndex = 3;
            // 
            // fitsc
            // 
            fitsc.AutoSize = true;
            fitsc.Location = new Point(111, 18);
            fitsc.Name = "fitsc";
            fitsc.Size = new Size(75, 19);
            fitsc.TabIndex = 2;
            fitsc.TabStop = true;
            fitsc.Text = "Fit screen";
            fitsc.UseVisualStyleBackColor = true;
            // 
            // stret
            // 
            stret.AutoSize = true;
            stret.Location = new Point(12, 18);
            stret.Name = "stret";
            stret.Size = new Size(62, 19);
            stret.TabIndex = 1;
            stret.TabStop = true;
            stret.Text = "Stretch";
            stret.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(3, 0);
            label3.Name = "label3";
            label3.Size = new Size(60, 15);
            label3.TabIndex = 0;
            label3.Text = "Wallpaper";
            // 
            // panel3
            // 
            panel3.Controls.Add(parallelrd);
            panel3.Controls.Add(serialrd);
            panel3.Controls.Add(label4);
            panel3.Location = new Point(350, 12);
            panel3.Name = "panel3";
            panel3.Size = new Size(334, 77);
            panel3.TabIndex = 3;
            // 
            // parallelrd
            // 
            parallelrd.AutoSize = true;
            parallelrd.Location = new Point(12, 43);
            parallelrd.Name = "parallelrd";
            parallelrd.Size = new Size(198, 19);
            parallelrd.TabIndex = 2;
            parallelrd.TabStop = true;
            parallelrd.Text = "All at once (may cause pc issues)";
            parallelrd.UseVisualStyleBackColor = true;
            // 
            // serialrd
            // 
            serialrd.AutoSize = true;
            serialrd.Location = new Point(12, 18);
            serialrd.Name = "serialrd";
            serialrd.Size = new Size(96, 19);
            serialrd.TabIndex = 1;
            serialrd.TabStop = true;
            serialrd.Text = "One at a time";
            serialrd.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(3, 0);
            label4.Name = "label4";
            label4.Size = new Size(47, 15);
            label4.TabIndex = 0;
            label4.Text = "Popups";
            // 
            // senddelch
            // 
            senddelch.AutoSize = true;
            senddelch.Location = new Point(122, 110);
            senddelch.Name = "senddelch";
            senddelch.Size = new Size(102, 19);
            senddelch.TabIndex = 13;
            senddelch.Text = "Send or Delete";
            senddelch.UseVisualStyleBackColor = true;
            // 
            // Options
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(700, 469);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(SvExit);
            Controls.Add(Popups);
            Name = "Options";
            Text = "Options";
            Load += Options_Load;
            Popups.ResumeLayout(false);
            Popups.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel Popups;
        private RadioButton longpop;
        private RadioButton shortpop;
        private Label label1;
        private Button SvExit;
        private Panel panel1;
        private CheckBox dlch;
        private CheckBox runch;
        private CheckBox wallpch;
        private CheckBox opwebch;
        private Label label2;
        private CheckBox popch;
        private CheckBox messch;
        private CheckBox sublimch;
        private CheckBox wrich;
        private CheckBox audioch;
        private CheckBox screenshch;
        private Panel panel2;
        private RadioButton fitsc;
        private RadioButton stret;
        private Label label3;
        private CheckBox twitch;
        private CheckBox watch4mech;
        private Panel panel3;
        private RadioButton parallelrd;
        private RadioButton serialrd;
        private Label label4;
        private CheckBox senddelch;
    }
}